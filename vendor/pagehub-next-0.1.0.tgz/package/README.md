# @pagehub/next

Serve a PageHub site at the root of your Next.js app. Any path your app has no page or route for is served by PageHub — including `/` once you delete `pages/index.tsx`. Your app's own pages and API routes keep working as they do now.

It's a config wrapper plus an optional middleware helper: no runtime dependencies, no components, nothing to render. Under the hood it adds two Next.js rewrites — a `fallback` to your PageHub site, and `/_pagehub/*` for the site's own forms, analytics and maps. The middleware helper takes over `/_pagehub/*` so PageHub also sees each visitor's IP.

```sh
npm install @pagehub/next
```

## Setup

1. **In PageHub,** turn on static publishing for the site and set its mount origin to your app's origin, e.g. `https://example.com` (MCP: `update_site({ mountOrigin: "https://example.com" })`).

2. **Wrap your Next.js config:**

   ```js
   // next.config.js
   const { withPageHub } = require("@pagehub/next");

   module.exports = withPageHub(config, { site: "<your-site-name>" });
   ```

   Your existing `rewrites()` still run first. Use `origin` instead of `site` to point at a custom domain or a local server, and `enabled: false` to turn it off for a build.

3. **If you send a Content-Security-Policy,** merge in `pagehubCspSources`:

   ```js
   const { pagehubCspSources } = require("@pagehub/next");
   // { "font-src": [...], "style-src": [...], "img-src": [...] }
   ```

   Add map tile, GSAP or analytics origins only if your PageHub pages use them.

4. **Pass along your visitors' IP addresses.** Rewrites can't add request headers, so without this step PageHub sees every visitor as your server. Form rate limits then hit everyone at once, and analytics counts all your visitors as one.

   Put the site's mount key in an environment variable (`PAGEHUB_MOUNT_KEY`) and handle `/_pagehub/*` in your middleware. On Next.js 16 that's `proxy.ts`; on older versions it's `middleware.ts`:

   ```ts
   // proxy.ts (or middleware.ts)
   import { NextResponse, type NextRequest } from "next/server";
   import { pagehubMiddleware } from "@pagehub/next";

   export function proxy(request: NextRequest) { // `middleware` on Next.js 15 and earlier
     const pagehub = pagehubMiddleware(request, {
       site: "<your-site-name>",
       mountKey: process.env.PAGEHUB_MOUNT_KEY,
     });
     if (pagehub) return pagehub;

     // Your own logic goes here, as before.
     return NextResponse.next();
   }

   export const config = { matcher: ["/_pagehub/:path*"] };
   ```

   If you already have a matcher, add `"/_pagehub/:path*"` to it. `pagehubMiddleware` returns `undefined` for every other path, so your logic still runs for them.

   PageHub receives the visitor's IP and, on Vercel, their country, region and city. Any `x-ph-*` headers a visitor sends are removed first, so they can't fake them. If `mountKey` is missing, requests still go through, just without the IP.

   Pages themselves don't need this. They're served by the fallback rewrite.

5. **Move pages over one at a time.** Delete a page from your app and PageHub serves that path from then on. Keep your app's own `public/robots.txt`. Delete `public/sitemap.xml` once every marketing page lives in PageHub.

## Limits

- The site must be static-published.
- PageHub mounts at the root only, not under a sub-path like `/site/*`.
- A page is either a PageHub page or an app page, never both.
