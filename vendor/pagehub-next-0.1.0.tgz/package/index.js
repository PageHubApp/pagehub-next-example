/** Contract shared with PageHub (utils/routing/customerHost.ts PAGEHUB_MOUNT_PREFIX). */
const PAGEHUB_MOUNT_PREFIX = "/_pagehub";

/** Request headers PageHub trusts from a mounted host app (checked against the site's mount key). */
const PAGEHUB_MOUNT_KEY_HEADER = "x-ph-mount-key";
const PAGEHUB_CLIENT_IP_HEADER = "x-ph-client-ip";
/** Every header this package sets starts with this; incoming ones are stripped first. */
const PAGEHUB_HEADER_PREFIX = "x-ph-";
/** Vercel edge geo header → the header forwarded to PageHub. */
const GEO_HEADERS = [
  ["x-vercel-ip-country", "x-ph-ip-country"],
  ["x-vercel-ip-country-region", "x-ph-ip-country-region"],
  ["x-vercel-ip-city", "x-ph-ip-city"],
  ["x-vercel-ip-latitude", "x-ph-ip-latitude"],
  ["x-vercel-ip-longitude", "x-ph-ip-longitude"],
];

/** CSP sources a mounted PageHub page needs beyond 'self' + 'unsafe-inline'. */
const pagehubCspSources = {
  "font-src": ["https://fonts.gstatic.com"],
  "style-src": ["https://fonts.googleapis.com"],
  "img-src": ["https://imagedelivery.net"],
};

/** `origin` (trailing slash stripped) wins over `site` → https://<site>.pagehub.dev. Throws when neither is set. */
function resolveUpstream(opts, caller) {
  const upstream = (opts.origin || (opts.site && `https://${opts.site}.pagehub.dev`) || "").replace(/\/$/, "");
  if (!upstream) throw new Error(`${caller}: pass \`site\` or \`origin\``);
  return upstream;
}

function normalizeRewrites(existing) {
  if (Array.isArray(existing)) return { beforeFiles: [], afterFiles: existing, fallback: [] };
  return {
    beforeFiles: existing?.beforeFiles ?? [],
    afterFiles: existing?.afterFiles ?? [],
    fallback: existing?.fallback ?? [],
  };
}

/**
 * Serve a static-published PageHub site at the app's root: every path the app
 * has no page/route for falls through to the site; the site's own browser
 * calls go through /_pagehub/*.
 *
 * @param {import("next").NextConfig | ((phase: string, ctx: any) => import("next").NextConfig | Promise<import("next").NextConfig>)} nextConfig
 *   an object config, or Next's function form `(phase, ctx) => config`
 * @param {{ site?: string, origin?: string, enabled?: boolean }} opts
 *   site    — PageHub site name (→ https://<site>.pagehub.dev)
 *   origin  — full upstream origin instead of `site` (custom domain, local dev)
 *   enabled — false returns nextConfig untouched (e.g. a build profile with no marketing)
 */
function withPageHub(nextConfig = {}, opts = {}) {
  if (opts.enabled === false) return nextConfig;
  const upstream = resolveUpstream(opts, "withPageHub");
  if (typeof nextConfig === "function") {
    return async (...args) => withPageHub(await nextConfig(...args), opts);
  }
  const userRewrites = nextConfig.rewrites;
  return {
    ...nextConfig,
    async rewrites() {
      const r = normalizeRewrites(userRewrites ? await userRewrites() : []);
      return {
        beforeFiles: r.beforeFiles,
        afterFiles: [
          ...r.afterFiles,
          { source: `${PAGEHUB_MOUNT_PREFIX}/:path*`, destination: `${upstream}/:path*` },
        ],
        fallback: [...r.fallback, { source: "/:path*", destination: `${upstream}/:path*` }],
      };
    },
  };
}

/**
 * Request headers for the upstream call: the incoming set minus any `x-ph-*`
 * (a visitor can't spoof them through the host), plus — when `mountKey` is
 * set — the mount key, the visitor IP and Vercel's geo for it.
 *
 * @param {Headers} incoming
 * @param {string | undefined} mountKey
 */
function pagehubRequestHeaders(incoming, mountKey) {
  const headers = new Headers(incoming);
  for (const key of [...headers.keys()]) {
    if (key.startsWith(PAGEHUB_HEADER_PREFIX)) headers.delete(key);
  }
  if (!mountKey) return headers;
  headers.set(PAGEHUB_MOUNT_KEY_HEADER, mountKey);
  const ip = incoming.get("x-forwarded-for")?.split(",")[0].trim() || incoming.get("x-real-ip")?.trim();
  if (ip) headers.set(PAGEHUB_CLIENT_IP_HEADER, ip);
  for (const [from, to] of GEO_HEADERS) {
    const value = incoming.get(from);
    if (value) headers.set(to, value);
  }
  return headers;
}

/**
 * Proxy `/_pagehub/*` from the host's middleware (`proxy.ts` / `middleware.ts`)
 * so PageHub sees the real visitor IP. Returns a rewrite for `/_pagehub/*`,
 * `undefined` for every other path so the host's own logic runs.
 *
 * @param {import("next/server").NextRequest} request
 * @param {{ site?: string, origin?: string, mountKey?: string }} opts
 *   site / origin — same as withPageHub
 *   mountKey      — the site's mount key; without it the rewrite still happens, minus the IP headers
 */
function pagehubMiddleware(request, opts = {}) {
  const { pathname, search } = request.nextUrl;
  if (!pathname.startsWith(`${PAGEHUB_MOUNT_PREFIX}/`)) return undefined;
  const upstream = resolveUpstream(opts, "pagehubMiddleware");
  const { NextResponse } = require("next/server");
  return NextResponse.rewrite(`${upstream}${pathname.slice(PAGEHUB_MOUNT_PREFIX.length)}${search}`, {
    request: { headers: pagehubRequestHeaders(request.headers, opts.mountKey) },
  });
}

module.exports = {
  withPageHub,
  pagehubMiddleware,
  pagehubCspSources,
  PAGEHUB_MOUNT_PREFIX,
  PAGEHUB_MOUNT_KEY_HEADER,
  PAGEHUB_CLIENT_IP_HEADER,
};
