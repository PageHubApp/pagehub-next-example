import type { NextConfig } from "next";
import type { NextRequest, NextResponse } from "next/server";

/** Path prefix the host app proxies to the PageHub site for the page's own browser calls. */
export declare const PAGEHUB_MOUNT_PREFIX: "/_pagehub";

/** Request header carrying the site's mount key, so PageHub trusts the headers below. */
export declare const PAGEHUB_MOUNT_KEY_HEADER: "x-ph-mount-key";

/** Request header carrying the visitor's IP (first `x-forwarded-for` entry, else `x-real-ip`). */
export declare const PAGEHUB_CLIENT_IP_HEADER: "x-ph-client-ip";

/** CSP sources a mounted PageHub page needs beyond 'self' + 'unsafe-inline'. */
export declare const pagehubCspSources: {
  readonly "font-src": string[];
  readonly "style-src": string[];
  readonly "img-src": string[];
};

export interface WithPageHubOptions {
  /** PageHub site name, served from https://<site>.pagehub.dev. */
  site?: string;
  /** Full upstream origin instead of `site` (custom domain, local dev). Wins over `site`. */
  origin?: string;
  /** `false` returns the config untouched. */
  enabled?: boolean;
}

/**
 * Serve a static-published PageHub site at the app's root: every path the app
 * has no page/route for falls through to the site; the site's own browser
 * calls go through /_pagehub/*. Throws when neither `site` nor `origin` is set.
 */
export type NextConfigFn = (phase: string, ctx: { defaultConfig: NextConfig }) => NextConfig | Promise<NextConfig>;

export declare function withPageHub(nextConfig?: NextConfig, opts?: WithPageHubOptions): NextConfig;
export declare function withPageHub(nextConfig: NextConfigFn, opts?: WithPageHubOptions): NextConfigFn;

export interface PageHubMiddlewareOptions {
  /** PageHub site name, served from https://<site>.pagehub.dev. */
  site?: string;
  /** Full upstream origin instead of `site` (custom domain, local dev). Wins over `site`. */
  origin?: string;
  /** The site's mount key, e.g. `process.env.PAGEHUB_MOUNT_KEY`. Without it the request is still proxied, but PageHub doesn't get the visitor's IP. */
  mountKey?: string;
}

/**
 * Proxy `/_pagehub/*` from your `proxy.ts` / `middleware.ts` so PageHub sees the
 * visitor's real IP and location. Returns a rewrite for `/_pagehub/*` and
 * `undefined` for every other path. Throws when neither `site` nor `origin` is set.
 */
export declare function pagehubMiddleware(
  request: NextRequest,
  opts?: PageHubMiddlewareOptions,
): NextResponse | undefined;
